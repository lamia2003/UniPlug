"""

Find all App functions here (advertising, networking & job opportunities)

"""


def ads(genre, price, address):
    """
    -------------------------------------------------------
    Generates Ad Posting
    -------------------------------------------------------
    """
    genre = str(input("Enter Genre: "))
    price = float(input("Enter Price: $ "))
    address = input("Enter Pickup Address: ")
    print()
    print(genre)
    print(price)
    print(address)
    return


def networking(name, program):
    """
    -------------------------------------------------------
    Connects people in the same program
    Use: networking(name, program)
    -------------------------------------------------------
    """
    name1 = str(input("Enter Name: "))
    program1 = str(input("Enter Program: "))
    name2 = str(input("Enter Name: "))
    program2 = str(input("Enter Program: "))
    chatroom = []
    if program1 == program2:
        chatroom.insert(name1)
        chatroom.insert(name2)
    return


def jobs(field, job_title, description, requirements):
    """
    -------------------------------------------------------
    Generates job posting
    Use: jobs(field, job_title, description, requirements)
    -------------------------------------------------------
    -------------------------------------------------------
    """
    field = str(input("Enter Field: "))
    job_title = str(input("Job Title: "))
    description = input("Provide a brief description of job roles: ")
    requirements = input("Enter Job Requirements")
    print()
    print(field)
    print(job_title)
    print(description)
    print(requirements)
    return
